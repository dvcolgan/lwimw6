using UnityEngine;
using System.Collections;

#if UNITY_EDITOR
using UnityEditor;
#endif

public interface IGATAudialReverb
{
	[FloatPropertyRange(0.5f,10)]
	float Time{get;set;}

	[FloatPropertyRange(0,1)]
	float DryWet{get;set;}
}

#if UNITY_EDITOR
[ InitializeOnLoad ]
#endif
public class GATAudialReverb : AGATMonoFilter, IGATAudialReverb
{
	public override System.Type ControlInterfaceType{ get{ return typeof( IGATAudialReverb ); } }

	private float sampleFrequency;
	void OnEnable(){
		sampleFrequency = GATInfo.OutputSampleRate;
		Initialize();
	}
	
	[SerializeField]
	private float _reverbTime = 1.55f;
	public float Time{
		get{
			return _reverbTime;
		}
		set{
			if(_reverbTime==value)return;
			_reverbTime = Mathf.Clamp(value,0.5f,10);
			CallibrateCombFilters();
		}
	}
	
	[SerializeField]
	private float _dryWet = 0.16f;
	public float DryWet{
		get{
			return _dryWet;
		}
		set{
			if(_dryWet==value)return;
			_dryWet = Mathf.Clamp(value,0,1);
		}
	}

	private bool   _processingEmptyData = true; // GZComment: need to flag when processing empty data starts
	private double _emptyTargetTime;            // And cache the target dsp time until which we'll still spit out data 
	
	public CombFilter[] combFilters;
	public class CombFilter{
		private float l;
		public float gain = 0.7f;
		public float[] delayBuffer;
		public float rvt;
		public float loopTime;
		
		public int pos = 0;
		
		public CombFilter(float r, float l, float sampleFrequency){
			rvt = r*1000;
			this.l = l;
			loopTime = l*((float)sampleFrequency/1000);
			gain = Mathf.Pow(0.001f,l/rvt);
			delayBuffer = new float[(int)loopTime];
		}
		
		public void Callibrate(float r){
			rvt = r*1000;
			gain = Mathf.Pow(0.001f,l/rvt);
		}
		
		public float ProcessSample(float sample){
			pos %= (int)loopTime;
			float output = delayBuffer[pos];
			delayBuffer[pos] = sample + delayBuffer[pos] * gain;
			pos++;
			return output;
		}

		public void Reset()
		{
			System.Array.Clear( delayBuffer, 0, delayBuffer.Length );
			pos = 0;
		}
	}
	public AllPassFilter[] allPassFilters;
	public class AllPassFilter{
		public float gain = 0.7f;
		public float[] delayBuffer;
		public float rvt;
		public float loopTime;
		
		public int pos = 0;
		
		public AllPassFilter(float r, float l, float sampleFrequency){
			rvt = r;
			loopTime = l*((float)sampleFrequency/1000);
			gain = Mathf.Pow(0.001f,l/rvt);
			delayBuffer = new float[(int)loopTime];
		}
		
		public float ProcessSample(float sample){
			pos %= (int)loopTime;
			float output = delayBuffer[pos];
			delayBuffer[pos] = sample + delayBuffer[pos] * gain;
			pos++;
			return output - gain*sample;
		}

		public void Reset()
		{
			System.Array.Clear( delayBuffer, 0, delayBuffer.Length );
			pos = 0;
		}
		
	}
	
	void Initialize(){
		combFilters = new CombFilter[4];
		combFilters[0] = new CombFilter(Time,29.7f, sampleFrequency);
		combFilters[1] = new CombFilter(Time,37.1f, sampleFrequency);
		combFilters[2] = new CombFilter(Time,41.1f, sampleFrequency);
		combFilters[3] = new CombFilter(Time,43.7f, sampleFrequency);
		
		allPassFilters = new AllPassFilter[2];
		allPassFilters[0] = new AllPassFilter(96.83f,5.0f, sampleFrequency);
		allPassFilters[1] = new AllPassFilter(32.92f,1.7f, sampleFrequency);
	}
	
	void CallibrateCombFilters(){
		if(combFilters==null)return;
		for(var i = 0; i < combFilters.Length; i++){
			combFilters[i].Callibrate(Time);
		}
	}
	
	public override int NbOfFilterableChannels{ get{ return 1; } }//Any, filter is pure linear processing

	public override bool ProcessChunk( float[] data, int fromIndex, int length, bool emptyData )
	{
		if( emptyData )
		{
			double dspTime = AudioSettings.dspTime;
			if( _processingEmptyData )
			{
				if( dspTime > _emptyTargetTime )
					return false;
			}
			else
			{
				_processingEmptyData = true;
				_emptyTargetTime	 = dspTime + ( double )_reverbTime;
			}
		}
		else
		{
			_processingEmptyData = false;
		}
			

		length += fromIndex;
		int i;

		for( i = fromIndex; i < length; i++ )
		{
			float combBase = data[i];
			for(var f = 0; f < combFilters.Length; f++){
				if(combFilters[f]==null) break;
				combBase += combFilters[f].ProcessSample(data[i]);
			}
			
			combBase /= combFilters.Length;
			
			float allPassBase = combBase / combFilters.Length;
			for(var a = 0; a < allPassFilters.Length; a++){
				allPassBase += allPassFilters[a].ProcessSample(combBase);
			}
			
			data[i] = data[i] * (1f-DryWet) + (allPassBase / allPassFilters.Length) * DryWet ;// allPassFilters.Length;
		}

		return true;
	}

	public override void ProcessChunk( float[] data, int fromIndex, int length, int stride )
	{
		length += fromIndex;
		int i;

		for( i = fromIndex; i < length; i++ )
		{
			float combBase = data[i];
			for(var f = 0; f < combFilters.Length; f++){
				if(combFilters[f]==null) break;
				combBase += combFilters[f].ProcessSample(data[i]);
			}
			
			combBase /= combFilters.Length;
			
			float allPassBase = combBase / combFilters.Length;
			for(var a = 0; a < allPassFilters.Length; a++){
				allPassBase += allPassFilters[a].ProcessSample(combBase);
			}
			
			data[i] = data[i] * (1f-DryWet) + (allPassBase / allPassFilters.Length) * DryWet ;// allPassFilters.Length;
		}
	}

	public override void ResetFilter() //GZComment: automatically called when toggling bypass in G-Audio's mixer
	{
		int i;
		_processingEmptyData = true;
		_emptyTargetTime 	 = 0d;

		for( i = 0; i < combFilters.Length; i++ )
		{
			combFilters[ i ].Reset ();
		}

		for( i = 0; i < allPassFilters.Length; i++ )
		{
			allPassFilters[ i ].Reset ();
		}
	}

	/// <summary>
	/// Not applicable: the filter is stateless and may filter any number of channels already.
	/// </summary>
	public override AGATMonoFilter GetMultiChannelWrapper < T > ( int nbOfChannels )
	{
		throw new GATException( "Audial Reverb( G-Audio version ) does not support multichannel audio - please use the standard Audial component instead." );
	}

	static GATAudialReverb()
	{
		AGATMonoFilter.RegisterMonoFilter( "Audial > Reverb", typeof( GATAudialReverb ) );

	}
}