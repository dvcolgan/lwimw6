using UnityEngine;
using System.Collections;

#if UNITY_EDITOR
using UnityEditor;
#endif

public interface IGATAudialCrusher
{	
	[FloatPropertyRange(1,32)]
	float Depth{get;set;}

	[FloatPropertyRange(0.001f,1)]
	float Rate{get;set;}

	[FloatPropertyRange(0,1)]
	float DryWet{get;set;}
}

#if UNITY_EDITOR
[ InitializeOnLoad ]
#endif
public class GATAudialCrusher : AGATMonoFilter, IGATAudialCrusher
{
	public override System.Type ControlInterfaceType{ get{ return typeof( IGATAudialCrusher ); } }

	[SerializeField]
	private float _bitDepth = 8;
	private int m;
	public float Depth{
		get{
			return _bitDepth;
		}
		set{
			if(_bitDepth==value)return;
			_bitDepth = Mathf.Clamp(value, 1,32);
			Callibrate();
		}
	}
	
	[SerializeField]
	private float _sampleRate = 0.1f;
	public float Rate{
		get{
			return _sampleRate;
		}
		set{
			if(_sampleRate==value)return;
			_sampleRate = Mathf.Clamp(value, 0.001f,1);
		}
	}
	
	[SerializeField]
	private float _dryWet = 1;
	public float DryWet{
		get{
			return _dryWet;
		}
		set{
			if(_dryWet==value)return;
			_dryWet = Mathf.Clamp(value,0,1);
		}
	}
	
	private float wet = 0;
	private float cnt = 0;
	
	void OnEnable(){
		Callibrate();
	}
	
	void Callibrate(){
		m = 1<<((int)Depth-1);
	}
	
	public override int NbOfFilterableChannels{ get{ return 999; } }//Any, filter is pure linear processing

	public override bool ProcessChunk( float[] data, int fromIndex, int length, bool emptyData )
	{
		if( emptyData )
			return false;

		length += fromIndex;
		int i;
		
		for( i = fromIndex; i < length; i++ )
		{
			cnt+=Rate;
			if(cnt>=1){
				cnt-=1;
				wet = ((int)(data[i]*m))/(float)m;
			}
			
			data[i] = data[i]*(1-DryWet) + wet*DryWet;
		}

		return true;
	}

	public override void ProcessChunk( float[] data, int fromIndex, int length, int stride )
	{
		length += fromIndex;
		int i;
		
		for( i = fromIndex; i < length; i+= stride )
		{
			cnt+=Rate;
			if(cnt>=1){
				cnt-=1;
				wet = ((int)(data[i]*m))/(float)m;
			}

			data[i] = data[i]*(1-DryWet) + wet*DryWet;
		}
	}

	public override void ResetFilter()
	{
		//Don't do anything, filter is passive
	}

	/// <summary>
	/// Not applicable: the filter is stateless and may filter any number of channels already.
	/// </summary>
	public override AGATMonoFilter GetMultiChannelWrapper < T > ( int nbOfChannels )
	{
		throw new GATException( "Crusher does not need multi channel wrappers - it can be applied safely to interlaced audio data" );
	}

	public GATAudialCrusher(){
		Callibrate();
	}

	static GATAudialCrusher()
	{
		AGATMonoFilter.RegisterMonoFilter( "Audial > Crusher", typeof( GATAudialCrusher ) );

	}
}