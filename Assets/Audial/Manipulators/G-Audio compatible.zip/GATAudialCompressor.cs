using UnityEngine;
using System.Collections;

#if UNITY_EDITOR
using UnityEditor;
#endif

public interface IGATAudialCompressor
{
	[FloatPropertyRange(0,3)]
	float InGain{get;set;}

	[FloatPropertyRange(0,1)]
	float Thresh{get;set;}

	[FloatPropertyRange(0,2)]
	float Slope{get;set;}

	[FloatPropertyRange(0.0001f,1)]
	float Attack{get;set;}

	[FloatPropertyRange(0.0001f,1)]
	float Release{get;set;}

	[FloatPropertyRange(0,5)]
	float OutGain{get;set;}
}

#if UNITY_EDITOR
[ InitializeOnLoad ]
#endif
public class GATAudialCompressor : AGATMonoFilter, IGATAudialCompressor
{
	public override System.Type ControlInterfaceType{ get{ return typeof( IGATAudialCompressor ); } }

	public float sampleFrequency;

	void OnEnable(){
		sampleFrequency = GATInfo.OutputSampleRate;
	}
	
	[SerializeField]
	private float _inputGain = 1;
	public float InGain{
		get{
			return _inputGain;
		}
		set{
			if(_inputGain==value)return;
			_inputGain = Mathf.Clamp(value,0,3);
		}
	}
	
	[SerializeField]
	private float _threshold = 0.247f;
	public float Thresh{
		get{
			return _threshold;
		}
		set{
			if(_threshold==value)return;
			_threshold = Mathf.Clamp(value,0,1);
		}
	}
	
	[SerializeField]
	public float _slope = 1.727f;
	public float Slope{
		get{
			return _slope;
		}
		set{
			if(_slope==value)return;
			_slope = Mathf.Clamp(value,0,2);
		}
	}
	
	[SerializeField]
	private float _attack = 0.0001f;
	private float _attackMod;
	public float Attack{
		get{
			return _attack;
		}
		set{
			if(_attack==value)return;
			_attack = Mathf.Clamp(value, 0.0001f, 1);
			_attackMod = Mathf.Exp(-1/(sampleFrequency * _attack));
		}
	}
	
	[SerializeField]
	public float _release = 0.68f;
	private float _releaseMod;
	public float Release{
		get{
			return _release;
		}
		set{
			if(_release==value)return;
			_release = Mathf.Clamp(value, 0.0001f, 1);
			_releaseMod = Mathf.Exp(-1/(sampleFrequency * _release));
		}
	}
	
	[SerializeField]
	private float _outputGain = 1;
	public float OutGain{
		get{
			return _outputGain;
		}
		set{
			if(_outputGain==value)return;
			_outputGain = Mathf.Clamp(value, 0, 5);
		}
	}
	
	private void Callibrate(){
		_attackMod = Mathf.Exp (-1/(sampleFrequency * _attack));
		_releaseMod = Mathf.Exp(-1/(sampleFrequency * _release));
	}
	
	private float env = 0;
	
	public override int NbOfFilterableChannels{ get{ return 999; } }//Any, filter is pure linear processing

	public override bool ProcessChunk( float[] data, int fromIndex, int length, bool emptyData )
	{
		if( emptyData )
			return false;

		length += fromIndex;
		int i;
		float input;
		
		for( i = fromIndex; i < length; i++ )
		{
			input = data[i] * InGain;;
			
			float rms = input;
			
			float theta = rms > env ? _attackMod : _releaseMod;
			
			env = (1-theta) * rms + theta * env;
			
			float gain = 1;
			
			if(env > Thresh)
				gain = Mathf.Clamp(gain - (env - Thresh) * Slope, 0, 1);
			
			data[i] = input * (gain * OutGain);
		}

		return true;
	}

	public override void ProcessChunk( float[] data, int fromIndex, int length, int stride )
	{
		length += fromIndex;
		int i;
		float input;
		
		for( i = fromIndex; i < length; i+= stride )
		{
			input = data[i] * InGain;

			float rms = input;
			
			float theta = rms > env ? _attackMod : _releaseMod;
			
			env = (1-theta) * rms + theta * env;
			
			float gain = 1;
			
			if(env > Thresh)
				gain = Mathf.Clamp(gain - (env - Thresh) * Slope, 0, 1);
			
			data[i] = input * (gain * OutGain);
		}
	}

	public override void ResetFilter()
	{
		//Don't do anything, filter is passive
	}

	/// <summary>
	/// Not applicable: the filter is stateless and may filter any number of channels already.
	/// </summary>
	public override AGATMonoFilter GetMultiChannelWrapper < T > ( int nbOfChannels )
	{
		throw new GATException( "Compressor does not need multi channel wrappers - it can be applied safely to interlaced audio data" );
	}

	public GATAudialCompressor(){
		Callibrate();
	}

	static GATAudialCompressor()
	{
		AGATMonoFilter.RegisterMonoFilter( "Audial > Compressor", typeof( GATAudialCompressor ) );

	}
}